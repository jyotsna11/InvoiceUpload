package com.einvoice;

import com.einvoice.property.FileStorageProperties;
import com.einvoice.service.FileStorageService;

public class TestMain {

	public static void main(String[] args) {
		
		FileStorageService service = new FileStorageService();
		
		service.uploadFileData("c:/uploads/Zoho Sales Register.xlsx");
	}
	
}
