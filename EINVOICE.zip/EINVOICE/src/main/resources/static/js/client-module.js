(function(){
    var app = angular.module('client', [
    'ui.bootstrap',
    'ngRoute', 'ngSanitize']);

    toastr.options.preventDuplicates = true;



})();
