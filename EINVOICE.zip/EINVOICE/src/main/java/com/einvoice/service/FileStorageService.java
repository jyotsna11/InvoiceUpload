package com.einvoice.service;
import java.nio.charset.*; 
import com.einvoice.exception.FileStorageException;
import com.einvoice.exception.MyFileNotFoundException;
import com.einvoice.property.FileStorageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.InvocationTargetException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@Service
public class FileStorageService {

    private final Path fileStorageLocation;
    
    public FileStorageService()
    {
		this.fileStorageLocation = null;
		}
    

    @Autowired
    public FileStorageService(FileStorageProperties fileStorageProperties) {
		this.fileStorageLocation = Paths.get(fileStorageProperties.getUploadDir())
                .toAbsolutePath().normalize();

        try {
        	Files.createDirectories(this.fileStorageLocation);
        	
        } catch (Exception ex) {
            throw new FileStorageException("Could not create the directory where the uploaded files will be stored.", ex);
        }
    }

    public String storeFile(MultipartFile file) {
        // Normalize file name
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());

        try {
            // Check if the file's name contains invalid characters
            if(fileName.contains("..")) {
                throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
            }

            // Copy file to the target location (Replacing existing file with the same name)
            Path targetLocation = this.fileStorageLocation.resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

            return fileName;
        } catch (IOException ex) {
            throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);
        }
    }

    public Resource loadFileAsResource(String fileName) {
        try {
            Path filePath = this.fileStorageLocation.resolve(fileName).normalize();
            Resource resource = new UrlResource(filePath.toUri());
            
            uploadFileData(String.valueOf(filePath));
            
            if(resource.exists()) {
               return resource;
      //      	return null;
            } else {
                throw new MyFileNotFoundException("File not found " + fileName);
            }
        } catch (MalformedURLException ex) {
            throw new MyFileNotFoundException("File not found " + fileName, ex);
        }
    }
    
 
    public String uploadFileData(String inputFilePath){
        Workbook workbook = null;
        Sheet sheet = null;
        try
        {
 
			//FileInputStream file = new FileInputStream(new File(inputFilePath));

            workbook = getWorkBook(new File(inputFilePath));
            sheet = workbook.getSheetAt(0);
 
            /*Build the header portion of the Output File*/

            String headerDetails= "Invoice Date,Invoice ID,Invoice Number,Estimate Number,Invoice Status,"
            		+ "Invoice Type,Customer Name,Customer ID,Place of Supply,Place of Supply(With State Code),"
            		+ "GST Treatment,"
            		+ "GST Identification Number (GSTIN),Is Inclusive Tax,Due Date,Expected Payment Date,"
            		+ "PurchaseOrder,Template Name,Currency Code,Exchange Rate,Discount Type,"
            		+ "Is Discount Before Tax,Entity Discount Percent,Entity Discount Amount,Account,"
            		+ "Item Name,Product ID,Item Desc,Quantity,Usage unit,Item Price,Discount,"
            		+ "Discount Amount,Expense Reference ID,Project ID,Project Name,HSN/SAC,Sales Order Number,"
            		+ "Supply Type,Tax ID,Item Tax,Item Tax %,Item Tax Amount,Item Tax Type,CGST Rate %,"
            		+ "	SGST Rate %,IGST Rate %,CESS Rate %,CGST(FCY),SGST(FCY),IGST(FCY),CESS(FCY),CGST,SGST,"
            		+ "IGST,CESS,Item Type,Item Tax Exemption Reason,Item Total,Custom Charges,"
            		+ "	Shipping Bill#,Shipping Bill Date,Shipping Bill Total,PortCode,Reference Invoice#,"
            		+ "Reference Invoice Date,GST Registration Number(Reference Invoice),Reason for issuing Debit Note,"
            		+ "SubTotal,Total,Balance,Shipping Charge,Adjustment,Adjustment Description,Round Off,"
            		+ "	Sales person,Payment Terms,Payment Terms Label,Last Payment Date,Notes,Terms & Conditions,"
            		+ "	Recurrence Name,PayPal,	Authorize.Net,Google Checkout,Payflow Pro,Stripe,2Checkout,"
            		+ "	Braintree,Forte,WorldPay,Payments Pro,Square,WePay,Razorpay,GoCardless,Partial Payments,"
            		+ "	Billing Address,Billing City,Billing State,Billing Country,Billing Code,Billing Phone,"
            		+ "	Billing Fax,Shipping Address,Shipping City,Shipping State,Shipping Country,Shipping Code,"
            		+ "Shipping Fax,"
            		+ "Shipping Phone Number,E-Commerce Operator Name,E-Commerce Operator GSTIN,"
            		+ "CF.Sales Type,IRN Code,BAR Code" ;
            String headerNames[] = headerDetails.split(",");
            
            /*Read and process each Row*/
			Cell cell = null;

			int lastRow = sheet.getLastRowNum();
			Random rand = new Random(); 
			Row row = null;
			    
			for(int i =1 ;i<lastRow;i++)
			{
				row = sheet.getRow(i);
				cell = sheet.getRow(i).getCell(headerNames.length-1);
				if(cell == null)
				{
				cell = row.createCell(headerNames.length-1);
				}
				cell.setCellValue(rand.nextInt(10000000));
				cell = sheet.getRow(i).getCell(headerNames.length-2);
				if(cell == null)
				{
					cell = row.createCell(headerNames.length-2);
				}
				
				cell.setCellValue(getAlphaNumericString(8));	
			}
			
			
			FileOutputStream outFile =new FileOutputStream(new File(inputFilePath));
			workbook.write(outFile);
			outFile.close();
            
 
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
 
        return "Success";
    }

    public static Workbook getWorkBook(File fileName)
    {
        Workbook workbook = null;
        try {
            String myFileName=fileName.getName();
            String extension = myFileName.substring(myFileName.lastIndexOf("."));
            if(extension.equalsIgnoreCase(".xls")){
                workbook = new HSSFWorkbook(new FileInputStream(fileName));
            }
            else if(extension.equalsIgnoreCase(".xlsx")){
                workbook = new XSSFWorkbook(new FileInputStream(fileName));
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return workbook;
    }
    
    public String getAlphaNumericString(int n)
    {
    	byte[] array = new byte[256]; 
        new Random().nextBytes(array); 
  
        String randomString = new String(array, Charset.forName("UTF-8")); 
        StringBuffer r = new StringBuffer(); 
  
        String  AlphaNumericString     = randomString .replaceAll("[^A-Za-z0-9]", ""); 
  
        // Append first 20 alphanumeric characters 
        // from the generated random String into the result 
        for (int k = 0; k < AlphaNumericString.length(); k++) { 
  
            if (Character.isLetter(AlphaNumericString.charAt(k)) 
                    && (n > 0) 
                || Character.isDigit(AlphaNumericString.charAt(k)) 
                       && (n > 0)) { 
  
                r.append(AlphaNumericString.charAt(k)); 
                n--; 
            } 
        } 
   
        return r.toString(); 
    }
    
    
    
    
}
