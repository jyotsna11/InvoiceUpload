package com.einvoice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EinvoiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
